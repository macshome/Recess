import Cocoa

extension TimeInterval {
    var minutes: TimeInterval { return self * 60 }
    var hours: TimeInterval { return self * 3_600 }
    var days: TimeInterval { return self * 86_400 }
    var weeks: TimeInterval { return self * 604_800 }
    var months: TimeInterval { return self * 2_628_000 }
}

let dateFormatter = DateFormatter()
dateFormatter.dateStyle = .medium
dateFormatter.timeZone = .none

let components = DateComponents(calendar: Calendar.current, year: 2019, month: 9, day: 0)
let kTrialExpire = Calendar.current.date(from: components)
let expire = kTrialExpire
let now = Date()
now.timeIntervalSince(expire!)

kTrialExpire?.timeIntervalSinceReferenceDate
dateFormatter.locale = Locale(identifier: "en_US")
print(dateFormatter.string(from: kTrialExpire!))
